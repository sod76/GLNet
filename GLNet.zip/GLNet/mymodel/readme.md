## origins

based on https://github.com/microsoft/Swin-Transformer#20240103

`main.py` and `utils/utils_ema.py` is modified from https://github.com/microsoft/Swin-Transformer#20240103, based on https://github.com/facebookresearch/ConvNeXt#20240103

