
from .models.vmamba import SS2D
import torch
import torch.nn as nn
from einops import rearrange

    

class LayerNorm2d(nn.LayerNorm):
    def forward(self, x: torch.Tensor):
        x = x.permute(0, 2, 3, 1)
        x = nn.functional.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        x = x.permute(0, 3, 1, 2)
        return x
        
class DepthWiseConv(nn.Module):
    def __init__(self, in_channel, out_channel):
  
        super(DepthWiseConv, self).__init__()

        self.depth_conv = nn.Conv2d(in_channels=in_channel,
                                    out_channels=in_channel,
                                    kernel_size=3,
                                    stride=1,
                                    padding=1,
                                    groups=in_channel)

        self.point_conv = nn.Conv2d(in_channels=in_channel,
                                    out_channels=out_channel,
                                    kernel_size=1,
                                    stride=1,
                                    padding=0,
                                    groups=1)


    def forward(self, input):
        out = self.depth_conv(input)
        out = self.point_conv(out)
        return out
        
class VM_CS(nn.Module):
    def __init__(self, in_channel,inputhw): 
        super(VM_CS, self).__init__()
        self.inputhw = inputhw
        self.in_channel = in_channel
        self.sqrt_c = int(in_channel ** 0.5)
        if self.sqrt_c * self.sqrt_c < in_channel:
           self.sqrt_c += 1
        else: 
           pass
        if self.sqrt_c*self.sqrt_c-in_channel != 0:
            self.padding_tensor = torch.zeros(1, inputhw[0]* inputhw[1],self.sqrt_c*self.sqrt_c-self.in_channel).cuda()
        else:
            self.padding_tensor = None
            
        self.norm = LayerNorm2d(in_channel) 
        self.dw = DepthWiseConv(in_channel,in_channel)
        self.pos_embed = nn.Parameter(torch.zeros(1, in_channel, inputhw[0], inputhw[1]))
        self.ss2d = SS2D(
                d_model=inputhw[-1]*inputhw[-2], 
                d_state=16, 
                ssm_ratio=2.0,
                dt_rank="auto",
                act_layer=nn.SiLU,
                d_conv= 3,
                conv_bias=True,
                forward_type="v2",
                channel_first="ln2d",
            )
        self.proj_low = nn.Linear(in_channel,in_channel//4)
        self.proj_hig = nn.Linear(in_channel//4,in_channel)
        self.sig = nn.Sigmoid()
                   
    def forward(self, input):
        x = input+self.pos_embed 
        x =  self.dw(self.norm(x))
        x = rearrange(x, "b c h w  -> b (h w) c", h=self.inputhw[0], w=self.inputhw[1], c = self.in_channel )
        x = self.to2d(x)
        x = self.ss2d(x)
        x = self.to1d(x)
        xl= self.proj_low(x)
        x = self.proj_hig(xl)+x
        x = rearrange(x, "b (h w) c -> b c h w", h=self.inputhw[0], w=self.inputhw[1], c = self.in_channel )
        return x
        
    def to2d(self,input):
        b,_,_ = input.shape
        if self.padding_tensor is not None:
            padding_tensor =  self.padding_tensor.expand(b, -1, -1)
            reshaped_tensor = torch.cat([input, padding_tensor], dim=-1)
        else:
            reshaped_tensor = input
        reshaped_tensor = rearrange(reshaped_tensor, "b l (h w) -> b l h w", l=self.inputhw[-1]*self.inputhw[-2],  h=self.sqrt_c, w=self.sqrt_c)
        return reshaped_tensor
    def to1d(self,input):
        reshaped_tensor = rearrange(input, "b l h w -> b l (h w)", l=self.inputhw[-1]*self.inputhw[-2],  h=self.sqrt_c, w=self.sqrt_c)
        unpaddingtensor = reshaped_tensor[:,:,: self.in_channel]
        return unpaddingtensor 
        
class VM_SS(nn.Module):
    def __init__(self, in_channel,inputhw):
        super(VM_SS, self).__init__()
        self.in_channel = in_channel
        self.inputhw = inputhw
        self.norm = LayerNorm2d(in_channel)
        self.dw = DepthWiseConv(in_channel,in_channel)
        self.pos_embed = nn.Parameter(torch.zeros(1, in_channel, inputhw[0], inputhw[1]))
        self.ss2d = SS2D(
                d_model=in_channel, 
                d_state=16, 
                ssm_ratio=2.0,
                dt_rank="auto",
                act_layer=nn.SiLU,
                d_conv= 3,
                conv_bias=True,
                forward_type="v2",
                channel_first="ln2d",
            )
        self.proj_low = nn.Linear(inputhw[-1]*inputhw[-2], inputhw[-1]*inputhw[-2]//4)
        self.proj_hig = nn.Linear(inputhw[-1]*inputhw[-2]//4, inputhw[-1]*inputhw[-2])
    def forward(self, input):
        x = input+self.pos_embed 
        x =  self.dw(self.norm(x))
        x = self.ss2d(x)
        x = rearrange(x, "b c h w -> b c (h w) ", h=self.inputhw[0], w=self.inputhw[1], c = self.in_channel )
        xl= self.proj_low(x)
        x = self.proj_hig(xl)+x
        x = rearrange(x, "b c (h w) -> b c h w", h=self.inputhw[0], w=self.inputhw[1], c = self.in_channel )
        
        return x  
if __name__ == '__main__':
  #model = SS2D(
  #              d_model=128, 
  #              d_state=16, 
  #              ssm_ratio=2.0,
  #              dt_rank="auto",
  #              act_layer=nn.SiLU,
  #              d_conv= 3,
  #              conv_bias=True,
  #              forward_type="v2",
  #              channel_first="ln2d",
  #          ).cuda()
  #model = VM_SC(256,[64,64]).cuda()
  model = VM_CS(2048,[8,8]).cuda()
  input_tensor = torch.FloatTensor(4,2048,8,8).cuda()
  out = model(input_tensor)
  print(out.shape)