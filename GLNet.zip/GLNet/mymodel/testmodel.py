
from .models.vmamba import VSSM
import torch

def getVSSM():
      model = VSSM(
        patch_size=4,           #config.MODEL.VSSM.PATCH_SIZE, 
        in_chans=3,             #config.MODEL.VSSM.IN_CHANS, 
        num_classes=1000,       #config.MODEL.NUM_CLASSES, 
        depths=[ 2, 2, 15, 2 ], #config.MODEL.VSSM.DEPTHS,      [2, 2, 9, 2]
        dims=128,               #config.MODEL.VSSM.EMBED_DIM,   96
        # ===================
        ssm_d_state=1,          #config.MODEL.VSSM.SSM_D_STATE, 16
        ssm_ratio=2.0,          #config.MODEL.VSSM.SSM_RATIO,   2.0
        ssm_rank_ratio=2.0,     #config.MODEL.VSSM.SSM_RANK_RATIO, 2.0
        ssm_dt_rank="auto",     #("auto" if config.MODEL.VSSM.SSM_DT_RANK == "auto" else int(config.MODEL.VSSM.SSM_DT_RANK)),"auto"
        ssm_act_layer="silu",    #config.MODEL.VSSM.SSM_ACT_LAYER,"silu"
        ssm_conv=3,              #config.MODEL.VSSM.SSM_CONV, 3
        ssm_conv_bias=False,     #config.MODEL.VSSM.SSM_CONV_BIAS,True
        ssm_drop_rate=0.0,       #config.MODEL.VSSM.SSM_DROP_RATE, 0.0
        ssm_init="v0",           #config.MODEL.VSSM.SSM_INIT,"v0"
        forward_type="v05_noz" ,  #config.MODEL.VSSM.SSM_FORWARDTYPE,"v2"
        # ===================
        mlp_ratio=4.0,           #config.MODEL.VSSM.MLP_RATIO, 4.0
        mlp_act_layer="gelu",    #config.MODEL.VSSM.MLP_ACT_LAYER,"gelu"
        mlp_drop_rate=0.0 ,      #config.MODEL.VSSM.MLP_DROP_RATE,
        # ===================
        drop_path_rate=0.6 ,     #config.MODEL.DROP_PATH_RATE,0.1
        patch_norm=True,         #config.MODEL.VSSM.PATCH_NORM,True
        norm_layer="ln2d",         #config.MODEL.VSSM.NORM_LAYER,"ln"
        downsample_version="v3", #config.MODEL.VSSM.DOWNSAMPLE,"v2"
        patchembed_version="v2", #config.MODEL.VSSM.PATCHEMBED,"v2"
        gmlp=False,              #config.MODEL.VSSM.GMLP,
        use_checkpoint=False,    #config.TRAIN.USE_CHECKPOINT,False
        # ===================
        posembed=False,          #config.MODEL.VSSM.POSEMBED,
        imgsize=224              #config.DATA.IMG_SIZE,
        )
        
      return model

if __name__ == '__main__':

  model = VSSM(
        patch_size=4,           #config.MODEL.VSSM.PATCH_SIZE, 
        in_chans=3,             #config.MODEL.VSSM.IN_CHANS, 
        num_classes=1000,       #config.MODEL.NUM_CLASSES, 
        depths=[ 2, 2, 15, 2 ], #config.MODEL.VSSM.DEPTHS,      [2, 2, 9, 2]
        dims=128,               #config.MODEL.VSSM.EMBED_DIM,   96
        # ===================
        ssm_d_state=1,          #config.MODEL.VSSM.SSM_D_STATE, 16
        ssm_ratio=2.0,          #config.MODEL.VSSM.SSM_RATIO,   2.0
        ssm_rank_ratio=2.0,     #config.MODEL.VSSM.SSM_RANK_RATIO, 2.0
        ssm_dt_rank="auto",     #("auto" if config.MODEL.VSSM.SSM_DT_RANK == "auto" else int(config.MODEL.VSSM.SSM_DT_RANK)),"auto"
        ssm_act_layer="silu",    #config.MODEL.VSSM.SSM_ACT_LAYER,"silu"
        ssm_conv=3,              #config.MODEL.VSSM.SSM_CONV, 3
        ssm_conv_bias=False,     #config.MODEL.VSSM.SSM_CONV_BIAS,True
        ssm_drop_rate=0.0,       #config.MODEL.VSSM.SSM_DROP_RATE, 0.0
        ssm_init="v0",           #config.MODEL.VSSM.SSM_INIT,"v0"
        forward_type="v05_noz" ,  #config.MODEL.VSSM.SSM_FORWARDTYPE,"v2"
        # ===================
        mlp_ratio=4.0,           #config.MODEL.VSSM.MLP_RATIO, 4.0
        mlp_act_layer="gelu",    #config.MODEL.VSSM.MLP_ACT_LAYER,"gelu"
        mlp_drop_rate=0.0 ,      #config.MODEL.VSSM.MLP_DROP_RATE,
        # ===================
        drop_path_rate=0.6 ,     #config.MODEL.DROP_PATH_RATE,0.1
        patch_norm=True,         #config.MODEL.VSSM.PATCH_NORM,True
        norm_layer="ln2d",         #config.MODEL.VSSM.NORM_LAYER,"ln"
        downsample_version="v3", #config.MODEL.VSSM.DOWNSAMPLE,"v2"
        patchembed_version="v2", #config.MODEL.VSSM.PATCHEMBED,"v2"
        gmlp=False,              #config.MODEL.VSSM.GMLP,
        use_checkpoint=False,    #config.TRAIN.USE_CHECKPOINT,False
        # ===================
        posembed=False,          #config.MODEL.VSSM.POSEMBED,
        imgsize=224              #config.DATA.IMG_SIZE,
        ).cuda()
  input_tensor = torch.FloatTensor(4,3,256,256).cuda()
  out = model(input_tensor)