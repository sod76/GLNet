import torch
from torch import nn
import torch.nn.functional as F

from torchvision.models import resnet50 as resnet
from einops import rearrange

class resnet50(nn.Module):
    def __init__(self,pretrained=True):
        super(resnet50, self).__init__()

        self.resnet = resnet()
        if pretrained:
            self.resnet.load_state_dict(torch.load('../pre_trained_weights/resnet50-19c8e357.pth'),strict=True)
            print("load resnet50 sucessfully!")
        self.drop = nn.Dropout2d(0.2)


    def forward(self,x):


        # top-down path
        x_u = self.resnet.conv1(x)
        x_u = self.resnet.bn1(x_u)
        x_u = self.resnet.relu(x_u)
        x_u0 = x_u
        x_u = self.resnet.maxpool(x_u)
        x_u0 = self.drop(x_u0)         #[64,256,256]

        x_u1 = self.resnet.layer1(x_u)
        x_u1 = self.drop(x_u1)         #[256,128,128]

        x_u2 = self.resnet.layer2(x_u1)
        x_u2 = self.drop(x_u2)         #[512,64,64]

        x_u3 = self.resnet.layer3(x_u2)
        x_u3 = self.drop(x_u3)         #[1024,32,32]

        x_u4 = self.resnet.layer4(x_u3)
        x_u4 = self.drop(x_u4)         #[2048,16,16]

        return x_u0, x_u1, x_u2,x_u3,x_u4  #[64,128,128] [256,64,64] [512,32,32] [1024,16,16] [2048,8,8]


def KL_loss(t, s , T=1):

    #input shape is bchw
    if t.shape[-2:] != s.shape[-2:]:
        t = F.interpolate(t, size=s.shape[-2:], mode='bilinear', align_corners=False)
    t_row = t.mean(dim=-1)
    t_row = torch.softmax(t_row / T, dim=-1)
    s_row = s.mean(dim=-1)
    s_row = torch.softmax(s_row / T, dim=-1)
    loss_row = t_row * torch.log(t_row + 1e-12) - t_row * torch.log(s_row + 1e-12)
    loss_row = loss_row.mean()

    t_col = t.mean(dim=-2)
    t_col = torch.softmax(t_col / T, dim=-1)
    s_col = s.mean(dim=-2)
    s_col = torch.softmax(s_col / T, dim=-1)
    loss_col = t_col * torch.log(t_col + 1e-12) - t_col * torch.log(s_col + 1e-12)
    loss_col = loss_col.mean()

    return (loss_row + loss_col)
if __name__ == '__main__':
    model = resnet50(pretrained=True)
    model = model.cuda()
    total = sum(p.numel() for p in model.parameters())
    print("Total params: %.4fM" % (total / 1e6))
    print(model)
    x = torch.FloatTensor(4, 3, 512, 512).cuda()
    print('input_size:', x.size())
    a = model(x)
    print(a.shape)
    # t = torch.FloatTensor([[0,1,2,3,4,5],
    #                   [6,5,8,9,10,11]]).unsqueeze(dim=0).unsqueeze(dim=0)
    # DETA = torch.randn(2, 1, 2, 6)
    # s = torch.FloatTensor([[6,7,8,9,10,11],[0,1,2,3,4,5]]).unsqueeze(dim=0).unsqueeze(dim=0)
    # loss_0 = KL_loss(0.1*t, 0.1*s+DETA, T=0.01)
    # loss_1 = KL_loss(0.1*t, 0.1*s+DETA, T=0.1)
    # loss_2 = KL_loss(0.1*t, 0.1*s+DETA, T=1)
    # loss_3 = KL_loss(0.1*t, 0.1*s+DETA, T=10) #
    #
    # print(loss_0)