from .mymodel.testmodel import getVSSM
# from vmamba import VSSM # debug use
import torch
from torch import nn
import torch.nn.functional as F

from .test_resnet import resnet50


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1 = nn.Conv2d(in_planes, in_planes // 16, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // 16, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()

        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return x


class SDI(nn.Module):
    def __init__(self, channel):
        super().__init__()

        self.convs = nn.ModuleList(
            [nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1) for _ in range(4)])

    def forward(self, xs, anchor):
        ans = torch.ones_like(anchor)
        target_size = anchor.shape[-1]

        for i, x in enumerate(xs):#[f1,f2,f3,f4]
            if x.shape[-1] > target_size:
                x = F.adaptive_avg_pool2d(x, (target_size, target_size))
            elif x.shape[-1] < target_size:
                x = F.interpolate(x, size=(target_size, target_size),
                                      mode='bilinear', align_corners=True)

            ans = ans * self.convs[i](x)

        return ans



class POE(nn.Module):

    def __init__(self,inchannel,outchannel):
        super(POE, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.rechannel = nn.Conv2d(in_channels=inchannel,
                                   out_channels=outchannel,
                                   kernel_size=1,stride=1)
    def forward(self, F_feature,SAM_feature,mask):
        b, c, h, w = F_feature.size()
        mb, mc, mh, mw = mask.size()
        #mask = F.softmax(mask, dim=1)
        #mask = mask[:,1,:,:].unsqueeze(dim=1)
        mask = torch.sigmoid(mask)
        sb, sc, sh, sw = SAM_feature.size()
        if (mh!=h) & (mw!=w):
            mask= F.interpolate(mask, (h,w), mode="bilinear", align_corners=False)
        SAM_feature = F.interpolate( SAM_feature, (h,w), mode="bilinear", align_corners=False)
        weight = h*w/(mask.sum(dim=-1).sum(dim=-1) + 1e-6).unsqueeze(dim=-1).unsqueeze(dim=-1)
        weight = weight.expand(mb, 1, mh, mw)
        Prototype = self.avg_pool(SAM_feature*mask)*weight
        Prototype = Prototype.expand(b, sc, h, w)
        Obj_f = torch.cat([F_feature, Prototype], dim=1)
        Obj_f = self.rechannel(Obj_f)
        return Obj_f
class DepthWiseConv(nn.Module):
    def __init__(self, in_channel, out_channel):
        # ��һ��ǧ��Ҫ����
        super(DepthWiseConv, self).__init__()

        # ��ͨ�����
        self.depth_conv = nn.Conv2d(in_channels=in_channel,
                                    out_channels=in_channel,
                                    kernel_size=3,
                                    stride=1,
                                    padding=1,
                                    groups=in_channel)

        # �����
        self.point_conv = nn.Conv2d(in_channels=in_channel,
                                    out_channels=out_channel,
                                    kernel_size=1,
                                    stride=1,
                                    padding=0,
                                    groups=1)


    def forward(self, input):
        out = self.depth_conv(input)
        out = self.point_conv(out)
        return out
        
class CPOE(nn.Module):
    def __init__(self, vminc, rinc):
        super(CPOE, self).__init__()
        self.dwv = DepthWiseConv(vminc, vminc)
        self.dwr = DepthWiseConv(rinc, rinc)
        self.poev2r = POE(inchannel=vminc+rinc, outchannel=vminc)
        self.poer2v = POE(inchannel=vminc+rinc, outchannel=rinc)
        self.rbn = nn.Sequential(
            nn.Conv2d( rinc, rinc, 3, stride=1, padding=1), nn.BatchNorm2d(rinc), nn.ReLU()
        )
        self.vbn = nn.Sequential(
            nn.Conv2d(vminc, vminc, 3, stride=1, padding=1), nn.BatchNorm2d(vminc), nn.ReLU()
        )
        self.cls = nn.Sequential(
            nn.Conv2d(vminc+rinc, vminc+rinc, 3, stride=1, padding=1), nn.BatchNorm2d( vminc+rinc), nn.ReLU(),
            nn.Conv2d(vminc + rinc, 1, 3, stride=1, padding=1)
        )
        self.rechannel = nn.Conv2d(in_channels=vminc+rinc,
                                   out_channels=vminc,
                                   kernel_size=1,stride=1)

    def forward(self, vm_f, r_f):
        vm_f = self.dwv(vm_f)
        r_f = self.dwr(r_f)
        mask = self.cls(torch.cat([vm_f,r_f],dim =1))

        rsat = self.poer2v( r_f, vm_f, mask)
        vmat = self.poev2r( vm_f, r_f, mask)
        vm_f = vm_f + self.vbn(vmat*vm_f)
        r_f = r_f + self.rbn(rsat * r_f)
        fusion = torch.cat([vm_f, r_f], dim=1)
        fusion = self.rechannel(fusion)
        mask =  F.interpolate( mask,[384,384], mode='bilinear')
        return fusion, mask
        
class SCAttn(nn.Module):
    def __init__(self, in_channels, act_fn=nn.GELU):
        super(SCAttn, self).__init__()

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.norm = nn.LayerNorm(in_channels)
        #self.temperature_c = nn.Parameter(torch.tensor(1.))
        self.moe_gate_c = nn.Sequential(nn.Linear(in_channels, in_channels//2), act_fn(),
                                        nn.Linear(in_channels//2, 4))
        self.channel_exper0 = nn.Sequential(nn.Linear(in_channels, in_channels//4),
                                            nn.Linear(in_channels // 4, in_channels))
        self.channel_exper1 = nn.Sequential(nn.Linear(in_channels, in_channels//8),
                                            nn.Linear(in_channels // 8, in_channels))
        self.channel_exper2 = nn.Sequential(nn.Linear(in_channels, in_channels//16),
                                            nn.Linear(in_channels // 16, in_channels))
        self.channel_exper3 = nn.Sequential(nn.Linear(in_channels, in_channels//32),
                                            nn.Linear(in_channels // 32, in_channels))
        self.sigc = nn.Sigmoid()
        self.sigs = nn.Sigmoid()

        self.spatial_squeeze = nn.Conv2d(in_channels, in_channels//8, kernel_size=1)
        self.avg_pool_s = nn.AdaptiveAvgPool2d(1)
        self.norm_s = nn.LayerNorm(in_channels//8)
        #self.temperature_s = nn.Parameter(torch.tensor(1.))
        self.moe_gate_s = nn.Sequential(nn.Linear(in_channels//8, in_channels//8), act_fn(),
                                        nn.Linear(in_channels//8, 4))
        self.spatial_exper0 = DepthWiseConv(in_channels//8, 1)
        self.spatial_exper1 = nn.Conv2d(in_channels//8, 1, kernel_size=1)
        self.spatial_exper2 = nn.Conv2d(in_channels//8, 1, kernel_size=3, padding=1, stride=1)
        self.spatial_exper3 = nn.Conv2d(in_channels//8, 1, kernel_size=5, padding=2, stride=1)


    def forward(self, x):
        ori_x = x
        ####Here channel Branch
        x = self.avg_pool(x).permute(0, 2, 3, 1)  #b,1,1,c
        gate_weightc = F.softmax(self.moe_gate_c(self.norm(x)), dim=-1).permute(0, 3, 1, 2) #b,4,1,1 /self.temperature_c
        x_ce0 = self.channel_exper0(x)
        x_ce1 = self.channel_exper1(x)
        x_ce2 = self.channel_exper2(x)
        x_ce3 = self.channel_exper3(x)
        c_out = gate_weightc[:, 0, :, :].unsqueeze(1)*x_ce0 + gate_weightc[:, 1, :, :].unsqueeze(1)*x_ce1\
                + gate_weightc[:, 2, :, :].unsqueeze(1)*x_ce2 + gate_weightc[:, 3, :, :].unsqueeze(1)*x_ce3
        c_at = self.sigc(c_out).permute(0, 3, 1, 2)
        ####Here spatial Branch
        x_s = self.spatial_squeeze(ori_x)
        x_ap = self.avg_pool_s(x_s).permute(0, 2, 3, 1)
        gate_weights = F.softmax(self.moe_gate_s(self.norm_s(x_ap)), dim=-1).permute(0, 3, 1, 2) # b,4,1,1/self.temperature_s
        x_se0 = self.spatial_exper0(x_s)
        x_se1 = self.spatial_exper1(x_s)
        x_se2 = self.spatial_exper2(x_s)
        x_se3 = self.spatial_exper3(x_s)
        s_out = gate_weights[:, 0, :, :].unsqueeze(1)*x_se0 + gate_weights[:, 1, :, :].unsqueeze(1)*x_se1 \
                + gate_weights[:, 2, :, :].unsqueeze(1)*x_se2 + gate_weights[:, 3, :, :].unsqueeze(1)*x_se3
        s_at = self.sigs(s_out)
        sc_at = c_at*s_at
        out = ori_x+ori_x*sc_at
        return out

         
class GLNet(nn.Module):
    def __init__(self, 
                 input_channels=3, 
                 num_classes=1,
                 mid_channel = 48,
                 depths=[2, 2, 9, 2], 
                 depths_decoder=[2, 9, 2, 2],
                 drop_path_rate=0.2,
                 load_ckpt_path=None,
                 deep_supervision=True
                ):
        super().__init__()

        self.load_ckpt_path = load_ckpt_path
        self.num_classes = num_classes
        self.resnet50_encoder =resnet50(pretrained=True)
        self.vmunet = getVSSM()
        #self.poe8 = CPOE(vminc=2048, rinc=2048)
        self.bottom = DepthWiseConv(in_channel=2048*2,out_channel=2048)
        self.poe16 = CPOE(vminc=512, rinc=1024)
        self.poe32 = CPOE(vminc=256, rinc=512)
        self.poe64 = CPOE(vminc=128, rinc=256)
        self.deconv4 = nn.Sequential(
            nn.Conv2d( 2048, 2048, 3, stride=1, padding=1),
            nn.ConvTranspose2d(2048, 2048, kernel_size=4, stride=2, padding=1, bias=False),
            nn.Conv2d( 2048, 512, 3, stride=1, padding=1), nn.BatchNorm2d(512), nn.ReLU(),
            
        )
        self.deconv3 = nn.Sequential(
            nn.Conv2d(512*3, 512, 3, stride=1, padding=1),
            nn.ConvTranspose2d(512, 512, kernel_size=4, stride=2, padding=1, bias=False),
            nn.Conv2d(512, 256, 3, stride=1, padding=1), nn.BatchNorm2d(256), nn.ReLU()
        )
        self.deconv2 = nn.Sequential(
            nn.Conv2d( 256*3, 256, 3, stride=1, padding=1), 
            nn.ConvTranspose2d(256, 256, kernel_size=4, stride=2, padding=1, bias=False),
            nn.Conv2d(256, 128, 3, stride=1, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
        )
        
        self.deconv1 = nn.Sequential( nn.Conv2d(128*3, 128, 3, stride=1, padding=1),
                     nn.ConvTranspose2d(128, 128, kernel_size=4, stride=2, padding=1, bias=False),
                     nn.Conv2d(128, 64, 3, stride=1, padding=1) )
                     
        self.cls128 = nn.Conv2d(64, 1, 3, stride=1, padding=1)
        self.cls = nn.Sequential(nn.Conv2d(64+64, 64+64, 3, stride=1, padding=1),
                                 nn.ConvTranspose2d(64+64, 64+64, kernel_size=4, stride=2, padding=1, bias=False),
                                 nn.Conv2d(64+64, 1, 3, stride=1, padding=1))
        #self.scat4 = SCAttn(2048)
        self.scat3 = SCAttn(512)
        self.scat2 = SCAttn(256)
        self.scat1 = SCAttn(128)

        
    def forward(self, x):
        
        if x.size()[1] == 1: # ����ǻҶ�ͼ���ͽ�1��channel תΪ3��channel
            x = x.repeat(1,3,1,1)
        flist = self.vmunet(x) #  f1 [2, 64, 64, 96]  f3  [2, 8, 8, 768]  [b h w c]
        f1, f2, f3, f4, f5 = flist[0], flist[1], flist[2], flist[3], flist[4]
        # b h w c --> b c h w
        #f1 = f1  #[4, 128, 64, 64]
        #f2 = f2  #[4, 256, 32, 32])
        #f3 = f3  #[4, 512, 16, 16]
        #f4 = f4  #[4, 1024, 8, 8])
        #f5 = f5  #[4, 1024, 8, 8])
        f_3 = self.scat3(f3)
        f_2 = self.scat2(f2)
        f_1 = self.scat1(f1)
        fr0,fr1,fr2,fr3,fr4 = self.resnet50_encoder(x) #[64,128,128] [256,64,64] [512,32,32] [1024,16,16] [2048,8,8]

        f4 = torch.cat([f4,f5],dim=1)
        #up_4,mask4 = self.poe8(f4,fr4)
        up_4 = self.bottom(torch.cat([f4,fr4],dim=1))
        up_3,mask3 = self.poe16(f3,fr3)
        up_2,mask2 = self.poe32(f2,fr2)
        up_1,mask1 = self.poe64(f1,fr1)

        up_d4 = self.deconv4(up_4) #16
        
        up_d3 = self.deconv3(torch.cat([up_3,f_3,up_d4],dim=1)) #32

        up_d2 = self.deconv2(torch.cat([up_2,f_2,up_d3],dim=1)) #64
        
        up_d1 = self.deconv1(torch.cat([up_1,f_1,up_d2],dim=1))#128
        
        #out = F.interpolate(up_d1, scale_factor=2, mode='bilinear')

        mask4 = self.cls128( up_d1 )
        mask4 = F.interpolate(mask4, scale_factor=2, mode='bilinear')
        
        out = self.cls(torch.cat([fr0,up_d1],dim=1))
        seg_outs = [out, mask1, mask2, mask3, mask4]
        return seg_outs

    
    def load_from(self):
        if self.load_ckpt_path is not None:
            model_dict = self.vmunet.state_dict()
            modelCheckpoint = torch.load(self.load_ckpt_path)
            pretrained_dict = modelCheckpoint['model']
            # ���˲���
            new_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict.keys()}
            model_dict.update(new_dict)
            # ��ӡ�����������˶��ٵĲ��� 
            print('Total model_dict: {}, Total pretrained_dict: {}, update: {}'.format(len(model_dict), len(pretrained_dict), len(new_dict)))
            self.vmunet.load_state_dict(model_dict)

            not_loaded_keys = [k for k in pretrained_dict.keys() if k not in new_dict.keys()]
            print('Not loaded keys:', not_loaded_keys)
            print("encoder loaded finished!")

if __name__ == '__main__':
    pretrained_path = '../pre_trained_weights/vssm_base_0229_ckpt_epoch_237.pth'
    model = GLNet(load_ckpt_path=pretrained_path, deep_supervision=True).cuda()
    model.load_from()
    x = torch.randn(2, 3, 256, 256).cuda()
    predict = model(x)
    # print(predict.shape)  #  deep_supervision true   predict[0] [2, 1, 256, 256] , predict[1] [2, 1, 128, 128] ���������ڼල
    
    

